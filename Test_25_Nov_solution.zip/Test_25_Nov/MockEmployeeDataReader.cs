using System.Collections.Generic;

namespace Test_25_Nov
{
    public class MockEmployeeDataReader : IEmployeeDataReader
    {
        private static readonly Dictionary<int, EmployeeRecord> _mock = new()
        {
            [101] = new EmployeeRecord { Id = 101, Name = "Priya Sharma", Role = "Developer", IsVeteran = false },
            [102] = new EmployeeRecord { Id = 102, Name = "Karthik Rao", Role = "Manager", IsVeteran = true },
            [103] = new EmployeeRecord { Id = 103, Name = "Sana Ali", Role = "Intern", IsVeteran = false },
            [104] = new EmployeeRecord { Id = 104, Name = "Arjun Kumar", Role = "Manager", IsVeteran = false }
        };

        public EmployeeRecord GetEmployeeRecord(int employeeId)
        {
            if (_mock.TryGetValue(employeeId, out var rec))
                return rec;

            return new EmployeeRecord
            {
                Id = employeeId,
                Name = "Unknown",
                Role = "Contractor",
                IsVeteran = false
            };
        }
    }
}
