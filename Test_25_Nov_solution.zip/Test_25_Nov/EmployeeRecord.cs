namespace Test_25_Nov
{
    public class EmployeeRecord
    {
        public int Id { get; init; }
        public string Name { get; init; } = string.Empty;
        public string Role { get; init; } = string.Empty;
        public bool IsVeteran { get; init; }
    }
}
