using System;
using System.Collections.Generic;

namespace Test_25_Nov
{
    public class PayrollProcessor
    {
        private readonly IEmployeeDataReader _dataReader;

        private static readonly Dictionary<int, decimal> BaseSalaries = new()
        {
            [101] = 65000m,
            [102] = 120000m,
            [103] = 20000m,
            [104] = 90000m
        };

        public PayrollProcessor(IEmployeeDataReader dataReader)
        {
            _dataReader = dataReader ?? throw new ArgumentNullException(nameof(dataReader));
        }

        private decimal GetBaseSalary(int employeeId) =>
            BaseSalaries.TryGetValue(employeeId, out var sal) ? sal : 0m;

        public decimal CalculateTotalCompensation(int employeeId)
        {
            var record = _dataReader.GetEmployeeRecord(employeeId);

            decimal bonus = record switch
            {
                { Role: "Manager", IsVeteran: true }  => 10000m,
                { Role: "Manager", IsVeteran: false } => 5000m,
                { Role: "Developer" }                 => 2000m,
                { Role: "Intern" }                    => 500m,
                _                                     => 0m
            };

            var baseSalary = GetBaseSalary(employeeId);
            return baseSalary + bonus;
        }
    }
}
