using System;
using Test_25_Nov;

class Program
{
    static void Main()
    {
        IEmployeeDataReader reader = new MockEmployeeDataReader();
        var payroll = new PayrollProcessor(reader);

        int[] demoIds = { 101, 102, 103, 104, 999 };

        foreach (var id in demoIds)
        {
            var total = payroll.CalculateTotalCompensation(id);
            Console.WriteLine($"Employee ID: {id}, Total Compensation: {total:C}");
        }

        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}
